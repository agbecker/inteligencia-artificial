## INF01048 - Inteligência Artificial <br/> Trabalho 1 - Aprendizado Supervisionado

#### Álvaro Guglielmin Becker - 00301391 <br/> Enzo Borges Segala - 00335314 <br/> Tomás Ruschel Canales da Trindade - 00326448
**Turma B**
**Professor Joel Carbonera**

---
### A* com heurística de Hamming
Nós expandidos: 18440
Custo da solução: 23
Tempo decorrido: 7.666 s

### A* com heurística de Manhattan
Nós expandidos: 2680
Custo da solução: 23
Tempo decorrido: 0.332 s